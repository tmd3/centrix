# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Login::Application.config.secret_token = 'cc78bac76f01e532fd6f04731edda253b0d738f90adc46ab636ac2dd2cd67b84798629bd6d8c9d451c28f83ba3f09f7aab89f88014b3f3e0a61b3bf25ed3be43'
