class InsuranceCo < ActiveRecord::Base
end
