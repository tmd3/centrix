class InsCoOffice < ActiveRecord::Base
end
