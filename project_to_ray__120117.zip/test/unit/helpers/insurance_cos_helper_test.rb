require 'test_helper'

class InsuranceCosHelperTest < ActionView::TestCase
end
