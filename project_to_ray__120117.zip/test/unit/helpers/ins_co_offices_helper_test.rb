require 'test_helper'

class InsCoOfficesHelperTest < ActionView::TestCase
end
