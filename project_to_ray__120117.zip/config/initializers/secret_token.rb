# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Centrix::Application.config.secret_token = '7e265eefc6c6a37a838190cb3c1d43330e8934bcf2bf0eba8df8b1afd1c1b27c932f50b6d1e802a6e7263a567730135a09047793e0ce32882128747e7fd56407'
